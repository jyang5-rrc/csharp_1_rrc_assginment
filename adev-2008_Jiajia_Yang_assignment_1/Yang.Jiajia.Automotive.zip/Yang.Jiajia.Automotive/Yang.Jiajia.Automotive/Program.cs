﻿/*
 * group activity team3
 * Members: Jiajia Yang,Bradley Schapf,Daniel Mejnov
 * Date:2022-01-13
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Yang.Jiajia.Automotive
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Car1
            Car car1 = new Car(2000, "Honda");

            car1.GetYearManufactured();
            Console.WriteLine(car1.GetYearManufactured());

            car1.SetYearManufactured(2004);
            Console.WriteLine(car1.GetYearManufactured());

            car1.GetManufacturer();
            Console.WriteLine(car1.GetManufacturer());

            car1.SetManufacturer("Infiniti");
            Console.WriteLine(car1.GetManufacturer());

            Console.WriteLine(car1.GetSpeed());

            car1.Accelerate();
            Console.WriteLine(car1.GetSpeed());

            car1.Accelerate(30);
            Console.WriteLine(car1.GetSpeed());

            car1.Brake();
            Console.WriteLine(car1.GetSpeed());


            //car2
            Car car2 = new Car(2012, "Honda",50);

            Console.WriteLine(car2.GetYearManufactured());

            car2.SetYearManufactured(2022);
            Console.WriteLine(car2.GetYearManufactured());

            Console.WriteLine(car2.GetManufacturer());

            car2.SetManufacturer("Ford");
            Console.WriteLine(car2.GetManufacturer());

            Console.WriteLine(car2.GetSpeed());

            car2.Accelerate();
            Console.WriteLine(car2.GetSpeed());

            car2.Accelerate(210);
            Console.WriteLine(car2.GetSpeed());

            car2.Brake();
            Console.WriteLine(car2.GetSpeed());


            Console.ReadKey();


        }


    }
}
