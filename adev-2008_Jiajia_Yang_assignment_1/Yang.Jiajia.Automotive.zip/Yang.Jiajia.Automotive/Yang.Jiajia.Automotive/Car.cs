﻿/*
 * group activity team3
 * Members: Jiajia Yang,Bradley Schapf,Daniel Mejnov
 * Date:2022-01-13
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Yang.Jiajia.Automotive
{
    internal class Car
    {
        private int MaximumSpeed = 200;
        private int yearManufactured;
        private string manufacturer;
        private int speed;
        private int speedIncrement;

        //+ Car(year : int, manufacturer : string)
        public Car(int year, string manufacturer)
            : this(year, manufacturer , 20)
           
        {
            
        }

        //+ Car(year : int, manufacturer : string, speedIncrement : int)
        public Car(int year, string manufacturer, int speedIncrement)
        {
            this.yearManufactured = year;
            this.manufacturer = manufacturer;
            this.speedIncrement = speedIncrement;
        }

        //+ GetYearManufactured() : int
        public int GetYearManufactured()
        {
            return this.yearManufactured;
        }

        //+ SetYearManufactured(year : int) : void
        public void SetYearManufactured(int year)
        {
            this.yearManufactured = year;
        }

        //+ GetManufacturer() : string
        public string GetManufacturer()
        {
            return this.manufacturer;
        }

        //+ SetManufacturer(manufacturer : string) : void
        public void SetManufacturer(string manufacturer)
        {
            this.manufacturer = manufacturer;
        }

        //+ GetSpeed() : int
        public int GetSpeed()
        {
            return this.speed;
        }

        //+ Accelerate() : void
        public void Accelerate()
        {
            if(speed + speedIncrement > MaximumSpeed)
            {

            }
            else
            {
                speed += speedIncrement;
            }
        }

        //+ Accelerate(speed : int) : void
        public void Accelerate(int speed)
        {
            if(speed > MaximumSpeed)
            {
                this.speed = MaximumSpeed; 
            }
            else if(speed > this.speed)
            {
                this.speed = speed;
            }
                  
        }

        //+ Brake() : void - Decreases the current speed by the speed increment. The Car’s speed will not go below zero.
        public void Brake()
        {
            speed -= speedIncrement;
        }
        


    }
}
