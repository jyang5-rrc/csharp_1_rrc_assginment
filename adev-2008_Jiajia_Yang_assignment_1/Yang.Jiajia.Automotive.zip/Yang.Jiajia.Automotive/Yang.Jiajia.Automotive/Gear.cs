﻿/*
 * group activity team3
 * Members: Jiajia Yang,Bradley Schapf,Daniel Mejnov
 * Date:2022-01-13
 */
namespace Yang.Jiajia.Automotive
{
    public enum Gear
    {
        Park = 0,
        First = 1,
        Second = 2,
        Third = 3,
        Fourth = 4,
        Reverse = 99
    }
}
    